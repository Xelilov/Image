import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_servises/auth.service';

@Component({
  selector: 'app-createlogo',
  templateUrl: './createlogo.component.html',
  styleUrls: ['./createlogo.component.css']
})
export class CreatelogoComponent implements OnInit {


  model: any = {};
  selectedFile: File;

  constructor(private authService: AuthService) { }

  ngOnInit() {
  }

  onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    console.log(event.target.files);
  }

  create() {
    const uploadData = new FormData();
    uploadData.append('File', this.selectedFile, this.selectedFile.name);
    uploadData.append('Name', this.model.Name);
    uploadData.append('Desctiption', this.model.Desctiption);
    console.log(uploadData);
    this.authService.create(uploadData);
  }

}
