import { Component, OnInit } from '@angular/core';
import { AuthService } from '../_servises/auth.service';
import { AlertifyService } from '../_servises/alertify.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  users: any;
  userdata: any;
  poputstyle: any = false;
  constructor(private authservis: AuthService, private alertify: AlertifyService) { }

  ngOnInit() {
    this.getusers();
  }

  popupstyle() {
    return this.poputstyle;
  }

  getusers() {
    this.authservis.callUser().subscribe(resp => {
      this.users = resp;
    }, error => {
      console.log(error);
    });
  }

  getValueById(id: any) {
    this.poputstyle = false;
    this.authservis.callDataById(id).subscribe(response => {
      this.userdata = response;
      if (this.userdata != null) {
        this.poputstyle = true;
      } else {
        this.alertify.error('Bu sirket haqqinda melumaq yoxdur');
      }
    }, error => {
      this.alertify.error('Bu sirket haqqinda melumaq yoxdur');
    });
  }

  closeInfo() {
    this.poputstyle = false;
  }


}
