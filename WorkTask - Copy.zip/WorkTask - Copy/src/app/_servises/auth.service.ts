import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';
import { AlertifyService } from './alertify.service';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  url = 'http://lupum.azurewebsites.net/api/';
  jwtHelper = new JwtHelperService();
  decodedToken: any;

  constructor(private http: HttpClient, private alertify: AlertifyService) { }

  login(model: any) {
    return this.http.post(this.url + 'auth/login', model)
      .pipe(
        map((response: any) => {
          const user = response;
          if (user) {
            localStorage.setItem('token', user.token);
            this.decodedToken = this.jwtHelper.decodeToken(user.token);
            console.log(this.decodedToken.nameid);
          }
        })
      );
  }

  loggedIn() {
    const token = localStorage.getItem('token');
    return !this.jwtHelper.isTokenExpired(token);
  }

  create(model: any) {
    let headers: HttpHeaders = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('Authorization', 'Bearer ' + localStorage.getItem('token'));
    console.log(headers);
    return this.http.post(this.url + 'users/' + this.decodedToken.nameid + '/companies', model, {
      reportProgress: true,
      observe: 'events',
      headers: headers
    }).subscribe(event => {
      this.alertify.success('Created'); // handle event here
    });
  }


  public callUser() {
    return this.http.get(this.url + 'company');
  }


  public callDataById(id: any) {
    return this.http.get(this.url + 'company/' + id);
  }

}
