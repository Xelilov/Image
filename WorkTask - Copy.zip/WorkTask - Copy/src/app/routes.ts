import { Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { CreatelogoComponent } from './createlogo/createlogo.component';
import { AuthGuard } from './_guards/auth.guard';

export const appRoutes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'create', component: CreatelogoComponent, canActivate: [AuthGuard] },
    { path: '**', redirectTo: 'home', pathMatch: 'full' }
];
